export { default } from './SettingsWindow.svelte';
